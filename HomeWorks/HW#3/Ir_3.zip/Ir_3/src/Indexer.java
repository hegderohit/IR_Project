import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;






public class Indexer {

	static HashMap<String, HashValue> tokenMap = new HashMap<String, HashValue>();
	static TreeMap<Integer, Integer> wordMap = new TreeMap<Integer, Integer>();
	static HashMap<Integer, Integer> dlength = new HashMap<Integer, Integer>();
	static int avgDocLen = 0;

	
	
	String filePath = readConfigurationfile();
	
	
	File directory = new File(filePath);
	File filenames[] = directory.listFiles();
	private BufferedReader br;

	public void BuildIndex() {
		try {
			for (int i = 0; i < filenames.length; i++) {
				int doclen = 0;
				Stemmer stemmer = new Stemmer();
				FileInputStream fstream = new FileInputStream(filenames[i]);
				DataInputStream in = new DataInputStream(fstream);
				br = new BufferedReader(new InputStreamReader(in));
				String curLine;
				while ((curLine = br.readLine()) != null) {
					ArrayList<String> words = new ArrayList<String>();
					String list[] = getWords(curLine, " ");
					int z = 0;
					if (list[z].startsWith("<") && list[z].endsWith(">")) {
						z++;
						continue;
					}
					for (z = 0; z < list.length; z++) {
						words.add(list[z]);
					}
					int len = words.size();
					if (len > 0) {
						for (int j = 0; j < len; j++) {
							if (words.get(j).equals(" ")
									|| words.get(j).equals(".")
									|| words.get(j).equals(",")
									|| words.get(j).equals("=")
									|| (words.get(j).startsWith("</") && words
											.get(j).endsWith(">"))
									|| words.get(j).equals("'")
									|| (words.get(j).startsWith("<") && words
											.get(j).endsWith(">"))
									|| words.get(j).equals("\\s")
									|| words.get(j).equals("\\r")
									|| words.get(j).equals("")
									|| words.get(j).equals("\\t")) {
								continue;
							} else if (words.get(j).contains(",")) {
								String data[] = getWords(words.get(j), ",");
								if (data.length > 0) {
									for (int r = 0; r < data.length; r++) {
										words.add(data[r]);
										len++;
									}
								}
							} else if (words.get(j).contains("=")) {
								String data[] = getWords(words.get(j), "=");
								if (data.length > 0) {
									for (int e = 0; e < data.length; e++) {
										words.add(data[e]);
										len++;
									}
								}
							} else if (words.get(j).contains("'")) {
								String data[] = getWords(words.get(j), "'");
								if (data.length > 0) {
									for (int e = 0; e < data.length; e++) {
										if (data[e].equals("s"))
											continue;
										else {
											words.add(data[e]);
											len++;
										}
									}
								}
							} else if (words.get(j).contains(".")) {
								String d[] = getWords(words.get(j), "\\.");
								if (d.length > 0) {
									for (int r = 0; r < d.length; r++) {
										words.add(d[r]);
										len++;
									}
								}
							} else if (words.get(j).contains("/")) {
								String data[] = getWords(words.get(j), "/");
								if (data.length > 0) {
									for (int r = 0; r < data.length; r++) {
										words.add(data[r]);
										len++;
									}
								}
							} else if (words.get(j).contains("(")) {
								String data[] = getWords(words.get(j), "[(]");
								if (data.length > 0) {
									for (int r = 0; r < data.length; r++) {
										words.add(data[r]);
										len++;
									}
								}
							} else if (words.get(j).contains(")")) {
								String data[] = getWords(words.get(j), "[)]");
								if (data.length > 0) {
									for (int r = 0; r < data.length; r++) {
										words.add(data[r]);
										len++;
									}
								}
							} else if (words.get(j).contains("-")) {
								String data[] = getWords(words.get(j), "-");
								if (data.length > 0) {
									for (int r = 0; r < data.length; r++) {
										words.add(data[r]);
										len++;
									}
								}
							} else {

								/*
								 * Porter Stemmer to stem the words to its
								 * native version
								 */

								char[] word = words.get(j).trim().toCharArray();

								stemmer.add(word, word.length);
								stemmer.stem();
								String newword = stemmer.toString();

								if (tokenMap.containsKey(newword)) {
									HashValue val = tokenMap.get(newword);
									if (val.tm.containsKey(i + 1)) {
										int tf = val.tm.get(i + 1);
										tf = tf + 1;
										val.tm.remove(j + 1);
										val.tm.put(i + 1, tf);
										val.dfreq();
										tokenMap.remove(newword);
										tokenMap.put(newword.toLowerCase(), val);
										doclen++;
									} else {
										val.tm.put(i + 1, 1);
										val.dfreq();
										tokenMap.put(newword.toLowerCase(), val);
										doclen++;
									}
								} else if (!newword.matches("\\W*")) {
									HashValue hv = new HashValue();
									hv.tm.put(i + 1, 1);
									hv.dfreq();
									tokenMap.put(newword.toLowerCase(), hv);
									doclen++;
								}
							}
						}
					}
					dlength.put((i + 1), doclen);
				}
				Iterator ditr = dlength.entrySet().iterator();
				int totaldoclen = 0;
				while (ditr.hasNext()) {
					Map.Entry dentry = (Map.Entry) ditr.next();
					totaldoclen = totaldoclen + (Integer) dentry.getValue();
				}

				avgDocLen = totaldoclen / filenames.length;

				/* Remove stop-words from the the Map */
				FileInputStream inFile = new FileInputStream(
						"/people/cs/s/sanda/cs6322/resourcesIR/stopwords");
				DataInputStream ins = new DataInputStream(inFile);
				BufferedReader breader = new BufferedReader(
						new InputStreamReader(ins));
				String strLn;
				while ((strLn = breader.readLine()) != null) {
					if (tokenMap.containsKey(strLn)) {
						tokenMap.remove(strLn);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		Iterator itrtr = tokenMap.entrySet().iterator();
		while (itrtr.hasNext()) {
			Map.Entry entry = (Map.Entry) itrtr.next();
			HashValue hval = (HashValue) entry.getValue();
			Iterator tmitr = hval.tm.entrySet().iterator();
			while (tmitr.hasNext()) {
				Map.Entry tmentry = (Map.Entry) tmitr.next();
				if (wordMap.containsKey(tmentry.getKey())) {
					if (wordMap.get(tmentry.getKey()) > (Integer) tmentry
							.getValue())
						continue;
					else {
						wordMap.remove(tmentry.getKey());
						wordMap.put((Integer) tmentry.getKey(),
								(Integer) tmentry.getValue());
					}
				} else {
					wordMap.put((Integer) tmentry.getKey(),
							(Integer) tmentry.getValue());
				}
			} 

		} 
	}

	public static String[] getWords(String data, String splitChar) {
		String[] words = null;
		try {
			words = data.split(splitChar);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return words;
	}
	
	public static String readConfigurationfile() {
		// TODO Auto-generated method stub
		String path = null;
		String fileName = "./input.txt";
		String currentLIne = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName));

			path = br.readLine();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return path;
	}
	
}