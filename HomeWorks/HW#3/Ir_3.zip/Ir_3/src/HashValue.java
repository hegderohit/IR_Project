
import java.util.TreeMap;
import java.io.Serializable;

public class HashValue implements Serializable{
	int df;	 
	MapComparator mycomparator;
	TreeMap<Integer, Integer> tm = new TreeMap<Integer, Integer>();
	public void dfreq(){
		df = tm.size();
	}	
}
