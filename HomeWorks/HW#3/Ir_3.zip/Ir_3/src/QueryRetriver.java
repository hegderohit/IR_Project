
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class QueryRetriver {

	/**
	 * author: Rohit
	 * @param args
	 */
	static HashMap<Integer,Double> weight1 = new HashMap<Integer, Double>();
	static HashMap<Integer,Double> weight2 = new HashMap<Integer, Double>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		Indexer indexer = new Indexer();
		Stemmer stemmer = new Stemmer();
		indexer.BuildIndex();		
		Set<String> qwords = new HashSet<String>();
		
		System.out.println("Enter the input query: ");
		weight1.clear();
		weight2.clear();
	    BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
	    String query = null;
        query = buffer.readLine();	         
        ArrayList<String> words = new ArrayList<String>();				
			String list[]=getWords(query," ");
			for(int z=0; z<list.length; z++){
				words.add(list[z]);
			}
			int len = words.size();
			if(len>0){
				for(int j=0; j<len; j++){							
				
					if(words.get(j).equals(" ")||words.get(j).equals(".")||words.get(j).equals(",")||words.get(j).equals("=")||
						(words.get(j).startsWith("</") && words.get(j).endsWith(">"))||words.get(j).equals("'")||
						(words.get(j).startsWith("<")&& words.get(j).endsWith(">"))|| words.get(j).equals("\\s")|| 
						words.get(j).equals("\\r")|| words.get(j).equals("")||words.get(j).equals("\\t")){
						continue;
					}
				
					else if(words.get(j).contains(",")){
						String data[]=getWords(words.get(j),",");
						if(data.length>0){				
							for(int r=0;r<data.length;r++){
								words.add(data[r]);										
								len++;								
							}
						}
					}
					else if(words.get(j).contains("=")){
						String data[]=getWords(words.get(j),"=");
						if(data.length>0){	
							for(int e=0; e<data.length; e++){
								words.add(data[e]);
								len++;
							}
						}
					}
					else if(words.get(j).contains("'")){
						String data[]=getWords(words.get(j),"'");
						if(data.length>0){	
							for(int e=0; e<data.length; e++){
								if(data[e].equals("s"))
									continue;
								else{
									words.add(data[e]);
									len++;
								}
							}									
						}
					}
					
					else if(words.get(j).contains(".")){
						String d[]=getWords(words.get(j),"\\.");
						if(d.length>0){
							for(int r=0;r<d.length;r++){
								words.add(d[r]);
								len++;										
							}
						}
					}
												
					else if(words.get(j).contains("/")){								
						String data[]=getWords(words.get(j),"/");
						if(data.length>0){
							for(int r=0;r<data.length;r++){
								words.add(data[r]);
								len++;										
							}
						}
					}
					else if(words.get(j).contains("(")){								
						String data[]=getWords(words.get(j),"[(]");
						if(data.length>0){
							for(int r=0;r<data.length;r++){
								words.add(data[r]);
								len++;
							}
						}
					}
					else if(words.get(j).contains(")")){								
						String data[]=getWords(words.get(j),"[)]");
						if(data.length>0){
							for(int r=0;r<data.length;r++){
								words.add(data[r]);
								len++;
							}
						}
					}
				
					else if(words.get(j).contains("-")){
						String data[]=getWords(words.get(j),"-");
						if(data.length>0){
							for(int r=0;r<data.length;r++){
								words.add(data[r]);
								len++;										
							}
						}
					}
					else{
						qwords.add(words.get(j).trim());
					}
				}
			}    	
        
       FileInputStream f = new FileInputStream("/people/cs/s/sanda/cs6322/resourcesIR/stopwords");
    	DataInputStream ins = new DataInputStream(f);
    	BufferedReader breader = new BufferedReader(new InputStreamReader(ins));
    	String sword;
    	while((sword=breader.readLine())!=null){    		
    		if(qwords.contains(sword)){
    			qwords.remove(sword);
    		}
    	}
    	
    	Set<String> qtokens = new HashSet<String>();
        Iterator<String> itr = qwords.iterator();
        while(itr.hasNext()){        	
        	String token = itr.next();        	
        	if(!token.matches("\\W*")){
        		char[] word = token.trim().toCharArray();
				stemmer.add(word, word.length);							//Using Porter Stemmer
				stemmer.stem();											//Stem the word
				String newword = stemmer.toString();
				qtokens.add(newword);
        	}
        }
        System.out.print("Query After Indexing --> ");
        Iterator<String> itrtr = qtokens.iterator();
        while(itrtr.hasNext()){
        	System.out.print(itrtr.next()+", ");
        }    
        calculate_weight(qtokens);
        topdocuments();
        
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	private static void topdocuments() {
		// TODO Auto-generated method stub
		try{
		Indexer indexer=new Indexer();
		String filePath = indexer.readConfigurationfile();
			
		File directory = new File(filePath);
		File filenames[]= directory.listFiles();
		List<Integer> mapKeys = new ArrayList<Integer>(weight1.keySet());
		List<Double> mapValues = new ArrayList<Double>(weight1.values());
		Collections.sort(mapValues);
		Collections.sort(mapKeys);
		Collections.reverse(mapValues);
		LinkedHashMap<Object, Object> someMap = new LinkedHashMap<Object, Object>();
		Iterator<Double> valueIt = mapValues.iterator();
		while (valueIt.hasNext()) {
			Object val = valueIt.next();
			Iterator<Integer> keyIt = mapKeys.iterator();
			while (keyIt.hasNext()) {
				Object key = keyIt.next();
				if (weight1.get(key).toString().equals(val.toString())) {
					weight1.remove(key);
					mapKeys.remove(key);
					someMap.put(key, val);
					break;
				}
			}
		}
		
		Iterator w1itr = someMap.entrySet().iterator();
		System.out.println();
		System.out.print("Top 10 docs for the query under Weight-1 --> ");
		for(int k=1; k<=10; k++){
			Map.Entry w1entry = (Map.Entry) w1itr.next();
			System.out.print(w1entry.getKey());
			System.out.print(", ");
		}
		Iterator w4itr = someMap.entrySet().iterator();
		for(int k=1; k<=10; k++){
			Map.Entry w4entry = (Map.Entry) w4itr.next();
			int doc = (Integer) w4entry.getKey();
			System.out.println();
			System.out.println("Rank # --> " +k +" ..... " +"Doc-ID #"+doc);
			System.out.println("Score  --> " +w4entry.getValue());
			
			
			FileInputStream fstream = new FileInputStream(filenames[doc-1]);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));  
		    Pattern pattern =  Pattern.compile("<TEXT>");//,Pattern.CASE_INSENSITIVE);  
		    Matcher matcher = null;  
		    String strline;
		    while((strline=br.readLine())!=null){
		            String line = strline;  
		            matcher = pattern.matcher(line);  
		            if(matcher.find()){  
		                System.out.println(br.readLine());  
		                break;
		            }  
		    }  
		}	
		List<Integer> mapKeys1 = new ArrayList<Integer>(weight2.keySet());
		List<Double> mapValues1 = new ArrayList<Double>(weight2.values());
		Collections.sort(mapValues1);
		Collections.sort(mapKeys1);
		Collections.reverse(mapValues1);
		LinkedHashMap<Object, Object> someMap1 = new LinkedHashMap<Object, Object>();
		Iterator<Double> valueIt1 = mapValues1.iterator();
		while (valueIt1.hasNext()) {
			Object val = valueIt1.next();
			Iterator<Integer> keyIt = mapKeys1.iterator();
			while (keyIt.hasNext()) {
				Object key = keyIt.next();
				if (weight2.get(key).toString().equals(val.toString())) {
					weight2.remove(key);
					mapKeys1.remove(key);
					someMap1.put(key, val);
					break;
				}
			}
		}
		Iterator w2itr = someMap1.entrySet().iterator();
		System.out.println();
		System.out.print("Top 10 docs for the query under Weight-2 --> ");
		for(int k=1; k<=10; k++){
			Map.Entry doc = (Map.Entry) w2itr.next();
			System.out.print(doc.getKey());
			System.out.print(", ");
		}
		Iterator w3itr = someMap1.entrySet().iterator();
		for(int k=1; k<=10; k++){
			Map.Entry docEntry = (Map.Entry) w3itr.next();
			System.out.println();
			System.out.println("Rank#  --> " +k+" ..... Doc-ID #"+docEntry.getKey());
			System.out.println("Score  --> " +docEntry.getValue());
			
			
			FileInputStream fstream = new FileInputStream(filenames[(Integer)docEntry.getKey()-1]);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));  
		    Pattern pattern =  Pattern.compile("<TEXT>");
		    Matcher matcher = null;  
		    String strline;
		    while((strline=br.readLine())!=null){
		            String line = strline;  
		            matcher = pattern.matcher(line);  
		            if(matcher.find()){  
		                System.out.println(br.readLine());  
		                break;
		            }  
		    }  
		}	
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}


	private static void calculate_weight(Set<String> qtokens) {
		// TODO Auto-generated method stub
		int collectionsize = 1400;
		int docf;
		int maxtf;
		int doclen;
		int avgdoclen = Indexer.avgDocLen;
		
		Iterator<String> itrtr = qtokens.iterator();
        while(itrtr.hasNext()){
        	String setword = itrtr.next();
        	if(Indexer.tokenMap.containsKey(setword)){
        		HashValue val = Indexer.tokenMap.get(setword);
        		Iterator<?> tmitr = val.tm.entrySet().iterator();
        		docf = val.df;
        		while(tmitr.hasNext()){
        			Map.Entry tmentry = (Map.Entry) tmitr.next();
        			Integer docid = (Integer) tmentry.getKey();
        			Integer termf = (Integer) tmentry.getValue();
        			
        			maxtf = Indexer.wordMap.get(docid);
        			doclen = Indexer.dlength.get(docid);
        			double w1 = (0.4 + 0.6 * Math.log (termf + 0.5) / Math.log (maxtf + 1.0))
        			* (Math.log (collectionsize / docf)/ Math.log (collectionsize));
        			
        			double w2 = (0.4 + 0.6 * (termf / (termf + 0.5 + 1.5 *
        					(doclen / avgdoclen))) * Math.log (collectionsize / docf)/
        					Math.log (collectionsize));
        			
        			if(weight1.containsKey(docid)){
        				double value = weight1.get(docid);
        				value = value + w1;
        				weight1.remove(docid);
        				weight1.put(docid, value);
        			}
        			else{
        				weight1.put(docid, w1);
        			}
        			if(weight2.containsKey(docid)){
        				double value1 = weight2.get(docid);
        				value1 = value1 + w2;
        				weight2.remove(docid);
        				weight2.put(docid, value1);
        			}
        			else{
        				weight2.put(docid, w2);
        			}
        		}
        	}
        }
	}



	public static String[] getWords(String data,String splitChar)
	{
		String[] words = null;
		try
		{
			words = data.split(splitChar);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return words;
	}
}
