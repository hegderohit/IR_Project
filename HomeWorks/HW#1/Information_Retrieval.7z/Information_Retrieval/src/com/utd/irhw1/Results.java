package com.utd.irhw1;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Results {

	public void DisplayResults(Map<String, Integer> tokens_list) {
		Results results = new Results();

		File f = new File("./Cranfield");
		String[] files = f.list();

		System.out
				.println("The average number of word tokens per document --> ");
		System.out.println((results.gettokencount(tokens_list) / files.length));
		System.out.println("\n");

		System.out.println("Size of the Dictionary -->" + tokens_list.size());
		System.out.println("\n");

		System.out.println("Total Number of Unique words-->"
				+ tokens_list.size());
		System.out.println("\n");

		System.out.println("Total Number of Words in the Collection --> ");
		System.out.println(results.gettokencount(tokens_list) + "\n");

		System.out.println("Total Number of Words appearing only once --> ");
		results.getSingleWords(tokens_list);
		System.out.println("\n");

	}

	private int gettokencount(Map<String, Integer> mp) {
		// TODO Auto-generated method stub
		Iterator it = mp.entrySet().iterator();
		int word_count = 0;
		while ((it.hasNext())) {
			Map.Entry pairs = (Map.Entry) it.next();
			int temp = (Integer) pairs.getValue();
			word_count = word_count + temp;
		}
		return (word_count);
	}

	public void getthirtyfrequentWords(Map<String, Integer> mp) {
		// TODO Auto-generated method stub
		System.out.println("TOp 30 Frequent words -->");
		Iterator it = mp.entrySet().iterator();
		int freq_count = 0;
		while ((it.hasNext()) && (freq_count <= 30)) {
			Map.Entry pairs = (Map.Entry) it.next();
			System.out.println(pairs.getKey() + " = " + pairs.getValue());
			freq_count++;
		}
	}

	public void getSingleWords(Map<String, Integer> mp) {

		Iterator it = mp.entrySet().iterator();
		int word_count = 0;
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			Integer temp = (Integer) pairs.getValue();
			if (temp == 1) {
				word_count++;
			}
			it.remove(); // avoids a ConcurrentModificationException
		}

		System.out.println(word_count);

		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			Integer temp = (Integer) pairs.getValue();
			if (temp == 1) {
				// System.out.println(pairs.getKey() + " = " +
				// pairs.getValue());
			}
			it.remove(); // avoids a ConcurrentModificationException
		}
	}

	public void printList(Map<String, Integer> mp) {
		Iterator it = mp.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			System.out.println(pairs.getKey() + " = " + pairs.getValue());

		}
	}

}
