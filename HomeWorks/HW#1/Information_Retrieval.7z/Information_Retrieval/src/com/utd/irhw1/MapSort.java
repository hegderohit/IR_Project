package com.utd.irhw1;

import java.util.Map;
import java.util.TreeMap;

public class MapSort {

	public static Map<String, Integer> sortByValue(Map<String, Integer> tokens_list) {
		// TODO Auto-generated method stub
		Map<String, Integer> sortedMap = new TreeMap<String, Integer>(new ValueComparator(tokens_list));
	    sortedMap.putAll(tokens_list);
	    return sortedMap;
	}
	
	 

}
