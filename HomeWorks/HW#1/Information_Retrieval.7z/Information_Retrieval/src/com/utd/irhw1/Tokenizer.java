package com.utd.irhw1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Tokenizer {

	public static ArrayList<String> stop_words = new ArrayList<String>();
	public static Map<String, Integer> tokens_list = new HashMap<String, Integer>();
	public static Map<String, Integer> soretd_tokens_list = new HashMap<String, Integer>();

	/*
	 * Calls the Read Files function which actually takes the Document path as
	 * the input and reads all the files one by one and the words are tokenized.
	 * 
	 * Map is sorted and stores in the tokens_list used for further proceedings.
	 * 
	 * Results is class to analyze and display the results from the Map. Takes
	 * the soretd_tokens_list as the input.
	 */

	public static void main(String[] args) {
		Tokenizer tokenizer = new Tokenizer();
		Results results = new Results();

		tokenizer.addStopWords(stop_words);
		tokenizer.readFiles();

		soretd_tokens_list = MapSort.sortByValue(tokens_list);
		// System.out.println( MapSort.sortByValue(tokens_list).size());
		results.DisplayResults(tokens_list);
		results.getthirtyfrequentWords(soretd_tokens_list);

	}

	/*
	 * Read the complete document in the File 'f' Get the list of all the files
	 * in that document Iterate over each file For each file, read line by line
	 * Split the read line using the delimiter REGEXP Tokenized words are stored
	 * in the Map tokens_list
	 * 
	 * updateList is a function which splits the words with " ' " delimiter and
	 * updates the hash map.
	 * 
	 * Fetch between the <TEXT> ....... </TEXT> tags then, Match
	 * the patterns between those tags and get the value
	 * 
	 * <TEXT> tags are fetched using 'jsoup' library. It reads the file and
	 * parses the text data between the given tags.
	 */

	private void readFiles() {
		// TODO Auto-generated method stub

		File f = new File("./Cranfield");
		String path = "./cranfield";
		String[] files = f.list();

		for (int i = 0; i < files.length; i++) {

			try {

				// JSOUP functions to parse the text
				String file_name = path + "/" + files[i];
				File input = new File(file_name);
				Document doc = Jsoup.parse(input, null);
				String line = doc.select("TEXT").toString();

				String[] tokens = line
						.split("[ ]|[.]|[,]|[-]|[/]|[+]|[0-9]|[)]|[(]|[:]|[=]|[*]");

				for (int j = 0; j < tokens.length; j++) {
					if (tokens[j].endsWith(">")) {

					} else if (tokens[j].startsWith("<")) {

					} else if (tokens[j].contains("<")) {

					} else if (stop_words.contains(tokens[j])) {

					} else if (tokens[j].contains("'")) {

						tokens_list = updateList(tokens_list, tokens[j]);
					} else {

						if (tokens_list.containsKey(tokens[j])) {
							int count = tokens_list.get(tokens[j]);
							count = count + 1;
							tokens_list.put(tokens[j], count);
						} else {
							tokens_list.put(tokens[j], 1);
						}
					}
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	private Map<String, Integer> updateList(Map<String, Integer> tokens_list2,
			String tokens) {

		// System.out.println(tokens);
		String key = null;
		if (tokens.startsWith("'")) {
			key = tokens.replace("'", "");

			if (tokens_list2.containsKey(key)) {
				int count = tokens_list2.get(key);
				count = count + 1;
				tokens_list2.put(key, count);
			} else {
				tokens_list2.put(key, 1);
			}

		} else if (tokens.endsWith("'")) {
			key = tokens.replace("'", "");

			if (tokens_list2.containsKey(key)) {
				int count = tokens_list2.get(key);
				count = count + 1;
				tokens_list2.put(key, count);
			} else {
				tokens_list2.put(key, 1);
			}

		} else if (tokens.endsWith("'s")) {
			// System.out.println(tokens);
			if (tokens_list2.containsKey(tokens)) {
				int count = tokens_list2.get(tokens);
				count = count + 1;
				tokens_list2.put(tokens, count);
			} else {
				tokens_list2.put(tokens, 1);
			}
		} else {

			String[] tok_temp = tokens.split("'");
			for (int k = 0; k < tok_temp.length; k++) {
				// System.out.println(tok_temp[k]);
				if (tokens_list2.containsKey(tok_temp[k])) {
					int count = tokens_list2.get(tok_temp[k]);
					count = count + 1;
					tokens_list2.put(tok_temp[k], count);
				} else {
					tokens_list2.put(tok_temp[k], 1);
				}
			}
		}

		return tokens_list2;

	}

	private void addStopWords(ArrayList<String> stop_words2) {
		// Adding words to the StopWord List
		BufferedReader br = null;
		String file_name = "./stopwords.txt";
		try {
			String sCurrentLine;
			br = new BufferedReader(new FileReader(file_name));

			while ((sCurrentLine = br.readLine()) != null) {
				String[] tokens = sCurrentLine.split(" ");

				for (int i = 0; i < tokens.length; i++) {
					stop_words.add(tokens[i]);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}

}
